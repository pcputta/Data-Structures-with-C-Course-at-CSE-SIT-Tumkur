#include "utils.c"
#ifndef INVENTORY_H_INCLUDED
#define INVENTORY_H_INCLUDED

struct stItemsInfo fnGetItemInfo(void);
void fnPutItemInfo(struct stItemsInfo);

#endif // INVENTORY_H_INCLUDED
