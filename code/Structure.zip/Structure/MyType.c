#include <stdio.h>
#include <stdlib.h>

typedef int MARKS;

int main()
{
    MARKS m1;

    printf("\nEnter Marks : ");
    scanf("%d", &m1);
    printf("\nMarks = %d\n", m1);
    return 0;
}

