#include<stdio.h>
main()
{
	printf("sdfbsdfm");
	getchar(); 
}
