#include <stdio.h>
#include <math.h>
main()
{
	double v,x,y,z;
	scanf("%lf%lf",&x,&y);
	//z=pow(x,y);
	v=sqrt(x);		
	printf("%lf",v);
}
